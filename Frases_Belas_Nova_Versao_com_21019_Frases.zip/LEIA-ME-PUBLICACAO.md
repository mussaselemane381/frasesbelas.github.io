# Frases Belas - versão com biblioteca de frases

Esta pasta contém a versão web do Frases Belas e os 17 ficheiros JSON da biblioteca de frases.

## Biblioteca incluída
- 17 categorias
- 21.019 frases
- Cada ficheiro `f-<categoria>.json` corresponde ao identificador usado pelo `index.html`.
- Os ficheiros JSON foram validados e as quantidades correspondem aos números declarados no código da aplicação.

## Publicação no GitHub Pages
1. Descompacte o ZIP.
2. Carregue o conteúdo desta pasta para a raiz do repositório `frasesbelas/frasesbelas.github.io`, mantendo os nomes dos ficheiros.
3. Não carregue apenas a pasta exterior do ZIP. `index.html`, `f-*.json`, `manifest.json`, `sw.js`, ícones e `privacidade.html` devem ficar juntos na raiz.
4. Aguarde a publicação do GitHub Pages e abra o site para testar as categorias.

O service worker foi atualizado para pré-carregar os ficheiros de frases e usa uma nova versão de cache (`fb-v3`).

## Nota de âmbito
Esta atualização integra a biblioteca de frases do arquivo fornecido na versão de aplicação que estava preparada. Não certifica, por si só, a conclusão dos jogos ou de outras funcionalidades ainda em desenvolvimento.
